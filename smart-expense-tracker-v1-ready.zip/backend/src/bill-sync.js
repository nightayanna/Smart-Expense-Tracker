
// Skeleton for Auto Bill Sync (Email Intelligence)
// Implement provider connectors (Gmail/Outlook) and parsing logic here.
// This file exposes a function `parseEmailForBill(subject, previewText, sender)` that returns:
// { isBill: boolean, amountDue: number | null, dueDate: string | null, vendor: string | null }
module.exports.parseEmailForBill = function(subject, previewText, sender) {
  const text = (subject + ' ' + (previewText || '')).toLowerCase();
  const keywords = ['bill', 'statement', 'invoice', 'payment due', 'your bill is ready', 'balance due', 'subscription renewal'];
  const isBill = keywords.some(k => text.includes(k));
  // crude amount extraction (regex for $ or numbers)
  const amountMatch = text.match(/\$\s?([0-9]+(?:\.[0-9]{1,2})?)/);
  const amount = amountMatch ? Number(amountMatch[1]) : null;
  // crude date extraction (YYYY-MM-DD or DD/MM/YYYY)
  const dateMatch = text.match(/(\d{4}-\d{2}-\d{2})|(\d{1,2}\/\d{1,2}\/\d{2,4})/);
  const dueDate = dateMatch ? dateMatch[0] : null;
  return { isBill, amountDue: amount, dueDate, vendor: sender };
};
