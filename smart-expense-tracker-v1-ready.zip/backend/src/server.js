
  require('dotenv').config();
  const express = require('express');
  const bodyParser = require('body-parser');
  const cors = require('cors');
  const { PrismaClient } = require('@prisma/client');
  const OpenAI = require('openai');

  const prisma = new PrismaClient();
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const app = express();
  app.use(cors());
  app.use(bodyParser.json());

  // Health
  app.get('/health', (req, res) => res.json({ ok: true }));

  // Simple transactions fetch (for testing)
  app.get('/api/transactions/:userId', async (req, res) => {
    const { userId } = req.params;
    const txs = await prisma.transaction.findMany({
      where: { userId },
      orderBy: { date: 'desc' },
      take: 200
    });
    res.json(txs);
  });

  // AI analytics route
  app.post('/api/analytics/ai', async (req, res) => {
    try {
      const { userId, timeframe = 'month' } = req.body;
      if (!userId) return res.status(400).json({ error: 'Missing userId' });

      const startDate = new Date();
      if (timeframe === 'month') startDate.setMonth(startDate.getMonth() - 1);
      if (timeframe === 'week') startDate.setDate(startDate.getDate() - 7);

      const transactions = await prisma.transaction.findMany({
        where: { userId, date: { gte: startDate } },
        orderBy: { date: 'desc' }
      });

      if (!transactions || transactions.length === 0) {
        return res.status(404).json({ error: 'No transactions found for this user.' });
      }

      // Precompute simple aggregates to reduce token usage
      const totalExpenses = transactions.reduce((s,t) => s + Number(t.amount), 0);
      const averageTransaction = totalExpenses / transactions.length;

      const prompt = `
You are a financial AI analyst for a Smart Expense Tracker app.
Analyze this user's ${timeframe} spending data and return a JSON response.

Transactions:
${JSON.stringify(transactions, null, 2)}

Return JSON with this structure:
{
  "summary": {
    "totalExpenses": number,
    "averageTransaction": number,
    "numberOfTransactions": number,
    "personalMessage": string
  },
  "spendingTrend": "increasing" | "decreasing" | "stable",
  "aiInsights": {
    "insights": [
      { "type": "warning" | "success" | "info", "title": string, "message": string, "category"?: string }
    ],
    "recommendations": [string],
    "predictions": [string]
  },
  "topSpendingCategories": [
    { "category": string, "amount": number }
  ]
}
Be concise, factual, and realistic.
Return ONLY JSON.
      `;

      // Call OpenAI Chat Completions (chat.completions.create)
      const completion = await openai.chat.completions.create({
        model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' },
        temperature: 0.7
      });

      const raw = completion.choices?.[0]?.message?.content || '{}';
      const result = typeof raw === 'string' ? JSON.parse(raw) : raw;

      // Attach computed fields for safety if missing
      if (!result.summary) {
        result.summary = {
          totalExpenses: Number(totalExpenses.toFixed(2)),
          averageTransaction: Number(averageTransaction.toFixed(2)),
          numberOfTransactions: transactions.length,
          personalMessage: ''
        };
      }

      res.json(result);
    } catch (err) {
      console.error('AI Analytics Error:', err);
      res.status(500).json({ error: 'Failed to generate AI analytics.' });
    }
  });

  const PORT = process.env.PORT || 4000;
  app.listen(PORT, () => console.log('Backend listening on', PORT));
