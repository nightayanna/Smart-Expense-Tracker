
# Smart Expense Tracker — Integrated Stack (Generated)

This project was prepared with:
- Backend (Express + Prisma) -> ./backend
- Prisma schema -> ./backend/prisma/schema.prisma
- Docker Compose -> ./docker-compose.yml
- Adminer UI for DB -> http://localhost:8080
- Auto Bill Sync skeleton -> ./backend/src/bill-sync.js

## Quick start (requires Docker)
1. Copy backend/.env.template to backend/.env and fill OPENAI_API_KEY.
2. From project root run:
   docker compose up -d --build
3. Initialize Prisma inside the backend container (once):
   docker compose exec backend npx prisma db push
4. (Optional) Seed the DB with transactions via Adminer or script.
5. Visit:
   - Frontend (if provided) -> http://localhost:5173
   - Backend -> http://localhost:4000/health
   - Adminer -> http://localhost:8080

## Notes
- The backend AI route calls OpenAI; set OPENAI_API_KEY in backend/.env.
- The Auto Bill Sync file is a parsing skeleton; you'll need to wire OAuth and provider connectors.
