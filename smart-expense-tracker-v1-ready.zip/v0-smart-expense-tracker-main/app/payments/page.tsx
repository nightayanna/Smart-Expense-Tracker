import { DashboardHeader } from "@/components/dashboard-header"
import { AutomatedPayments } from "@/components/automated-payments"
import { AISummary } from "@/components/ai-summary"

export default function PaymentsPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-3xl font-bold">Automated Payments</h1>
          <p className="text-muted-foreground">Manage your bills and automated payments</p>
        </div>

        {/* AI Summary */}
        <AISummary
          summary="You have 5 upcoming bills this month totaling JMD $23,400. All payments are scheduled and on track. Your water bill is due in 3 days."
          insights={[
            "Your electricity bill is 15% higher than last month",
            "Consider switching to annual billing for Netflix to save JMD $1,200/year",
            "You have 3 subscriptions that haven't been used in 30 days",
          ]}
        />

        {/* Automated Payments Component */}
        <AutomatedPayments />
      </main>
    </div>
  )
}
