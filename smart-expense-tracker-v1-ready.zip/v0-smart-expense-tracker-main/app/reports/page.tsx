import { DashboardHeader } from "@/components/dashboard-header"
import { SpendingGps } from "@/components/spending-gps"
import { SmartGuardrails } from "@/components/smart-guardrails"
import { GoalAccelerator } from "@/components/goal-accelerator"
import { FutureShockDetection } from "@/components/future-shock-detection"
import { WealthUpliftCoach } from "@/components/wealth-uplift-coach"
import { AiSummary } from "@/components/ai-summary"

export default function ReportsPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Page Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">AI Financial Insights</h1>
            <p className="text-muted-foreground">Intelligent analysis and predictions for your financial future</p>
          </div>
        </div>

        <AiSummary tab="reports" />

        <div className="space-y-6">
          <SpendingGps />

          <div className="grid lg:grid-cols-2 gap-6">
            <SmartGuardrails />
            <GoalAccelerator />
          </div>

          <FutureShockDetection />

          <WealthUpliftCoach />
        </div>
      </main>
    </div>
  )
}
